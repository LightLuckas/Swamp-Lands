<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="terrain_tiles" tilewidth="32" tileheight="32" tilecount="60" columns="10">
 <image source="../../graphics/terrain/terrain_tiles.png" width="320" height="192"/>
</tileset>
