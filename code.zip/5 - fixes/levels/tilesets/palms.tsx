<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="palms" tilewidth="32" tileheight="32" tilecount="13" columns="13">
 <image source="../../graphics/terrain/palm_bg/palm_bg.png" width="416" height="32"/>
</tileset>
