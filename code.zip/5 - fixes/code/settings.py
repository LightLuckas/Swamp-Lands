vertical_tile_number = 22
tile_size = 32

screen_height = vertical_tile_number * tile_size
screen_width = 1200

