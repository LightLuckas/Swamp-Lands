import pygame
import sys
from decoration import Sky  # Assuming your Sky class is in a file named sky.py

class MainMenu:
    def __init__(self, screen, clock, database):
        self.screen = screen
        self.clock = clock
        self.db = database
        self.font = pygame.font.Font(None, 36)

        # Create an instance of the Sky class for the background
        self.sky = Sky(horizon=5, style='overworld')

        screen_width, screen_height = self.screen.get_size()
        center_x = screen_width // 2
        center_y = screen_height // 2

        # Размеры кнопок и пространство между ними
        button_width = 200
        button_height = 50
        spacing = 20

        self.play_button = pygame.Rect(center_x - button_width // 2, center_y - button_height - spacing // 2, button_width, button_height)
        self.exit_button = pygame.Rect(center_x - button_width // 2, center_y + spacing // 2, button_width, button_height)

        self.font = pygame.font.Font('../graphics/ui/ARCADEPI.ttf', 36)
        self.coin_sound = pygame.mixer.Sound('../audio/effects/coin.wav')

    def show(self, screen):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self.play_button.collidepoint(event.pos):
                        self.coin_sound.play()
                        self.show_play_menu(screen)
                    elif self.exit_button.collidepoint(event.pos):
                        pygame.quit()
                        sys.exit()

            # Draw the sky background
            self.sky.draw(self.screen)

            pygame.draw.rect(self.screen, (0, 128, 255), self.play_button)
            pygame.draw.rect(self.screen, (255, 0, 0), self.exit_button)

            play_text = self.font.render("Play", True, (255, 255, 255))
            exit_text = self.font.render("Exit", True, (255, 255, 255))

            self.screen.blit(play_text, (self.play_button.x + 10, self.play_button.y + 10))
            self.screen.blit(exit_text, (self.exit_button.x + 10, self.exit_button.y + 10))

            pygame.display.flip()
            self.clock.tick(30)

    def show_play_menu(self, screen):
        create_sound_played = False
        from main import Game

        screen_width, screen_height = self.screen.get_size()
        center_x = screen_width // 2
        center_y = screen_height // 2

        # Размеры кнопок и пространство между ними
        button_width_large = 400
        button_height_large = 50
        spacing_large = 20

        create_account_button = pygame.Rect(center_x - button_width_large // 2,
                                            center_y - button_height_large - spacing_large // 2, button_width_large,
                                            button_height_large)
        existing_account_button = pygame.Rect(center_x - button_width_large // 2, center_y + spacing_large // 2,
                                              button_width_large, button_height_large)


        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if create_account_button.collidepoint(event.pos):
                        if not create_sound_played:
                            self.coin_sound.play()
                            create_sound_played = True
                        username = get_username_from_input(self.screen, self.clock, self.sky)
                        if self.create_account(username):
                            return
                    elif existing_account_button.collidepoint(event.pos):
                        if not create_sound_played:
                            self.coin_sound.play()
                            create_sound_played = True
                        username = get_username_from_input(self.screen, self.clock, self.sky)
                        if self.existing_account(username):
                            game = Game(username, self.db)
                            while True:
                                for event in pygame.event.get():
                                    if event.type == pygame.QUIT:
                                        pygame.quit()
                                        sys.exit()

                                # Draw the sky background
                                self.sky.draw(self.screen)

                                game.run()

                                pygame.display.update()
                                self.clock.tick(60)

            # Draw the sky background
            self.sky.draw(self.screen)

            pygame.draw.rect(self.screen, (0, 128, 255), create_account_button)
            pygame.draw.rect(self.screen, (255, 0, 0), existing_account_button)

            create_text = self.font.render("Create Account", True, (255, 255, 255))
            existing_text = self.font.render("Existing Account", True, (255, 255, 255))

            self.screen.blit(create_text, (
                create_account_button.centerx - create_text.get_width() // 2, create_account_button.y + 10))
            self.screen.blit(existing_text, (
                existing_account_button.centerx - existing_text.get_width() // 2, existing_account_button.y + 10))

            pygame.display.flip()
            self.clock.tick(30)

    def create_account(self, username):
        if self.db.get_user_data(username):
            self.show_message("Username is already taken. Please choose another.")
            return False

        self.db.create_user(username)
        self.show_message(f"Account created successfully for {username}.")
        return True

    def existing_account(self, username):
        user_data = self.db.get_user_data(username)
        if not user_data:
            self.show_message("Account not found. Please enter a valid username.")
            return False

        self.show_message(f"Welcome back, {username}!")
        return True

    def show_message(self, message):
        message_font = pygame.font.Font('../graphics/ui/ARCADEPI.ttf', 36)  # Change the font
        message_text = message_font.render(message, True, (255, 255, 255))
        message_rect = message_text.get_rect(midtop=self.screen.get_rect().midtop)

        # Draw the sky background
        self.sky.draw(self.screen)

        self.screen.blit(message_text, message_rect)

        pygame.display.flip()
        pygame.time.wait(2000)  # Отображаем сообщение 2 секунды


class TextInputBox:
    def __init__(self, x, y, width, height, font, color, max_length):
        self.rect = pygame.Rect(x, y, width, height)
        self.font = font
        self.color = color
        self.text = ''
        self.is_active = False
        self.max_length = max_length  # New attribute to store the maximum length

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.is_active = self.rect.collidepoint(event.pos)
        elif event.type == pygame.KEYDOWN and self.is_active:
            if event.key == pygame.K_RETURN:
                self.is_active = False
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                # Check if the text length is within the maximum allowed length
                if len(self.text) < self.max_length:
                    self.text += event.unicode

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, 2)
        text_surface = self.font.render(self.text, True, self.color)
        screen.blit(text_surface, (self.rect.x + 5, self.rect.y + 5))

def get_username_from_input(screen, clock, sky):
    font = pygame.font.Font('../graphics/ui/ARCADEPI.ttf', 36)

    input_box = TextInputBox(50, 50, 400, 50, font, pygame.Color('black'), max_length=13)
    input_active = True

    while input_active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            input_box.handle_event(event)

        screen.fill('grey')
        input_box.rect.x = (screen.get_width() - input_box.rect.width) // 2
        input_box.rect.y = (screen.get_height() - input_box.rect.height) // 2

        # Draw the sky background
        sky.draw(screen)

        input_box.draw(screen)
        pygame.display.flip()
        clock.tick(30)

        if not input_box.is_active and input_box.text:
            input_active = False

    return input_box.text