import sqlite3

class Database:
    def __init__(self, database_path='game_database.db'):
        self.conn = sqlite3.connect(database_path)
        self.cursor = self.conn.cursor()

    def create_user(self, username):
        self.cursor.execute("INSERT INTO users (username, max_level, coins) VALUES (?, ?, ?)", (username, 0, 0))
        self.conn.commit()

    def get_user_data(self, username):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        return self.cursor.fetchone()

    def update_user_data(self, username, max_level, coins):
        self.cursor.execute("UPDATE users SET max_level=?, coins=? WHERE username=?", (max_level, coins, username))
        self.conn.commit()

    def close_connection(self):
        self.conn.close()